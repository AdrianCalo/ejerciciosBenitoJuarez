var s: number;
var a: number;
s = 0;
a = 2;

for (let i = 100; i > 0; i = i - 1) {
  s = Number(s + a);
}
console.log(s);

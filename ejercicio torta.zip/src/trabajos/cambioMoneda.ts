import "./styles.css";

const dolar: number = 296;
const libra: number = 345;
const euro: number = 305;
let userPesos: number;
let userMoney: number;
let resultadoFinal: number;

let pesosArg = document.getElementById("pesos");
let otraMoneda = document.getElementById("money");
let btnConv = document.getElementById("cash");
let parrafoRes = document.getElementById("textoFinal");

btnConv.addEventListener("click", () => {
  userPesos = Number(pesos.value);
  userMoney = Number(money.value);

  if (userMoney == 1) {
    resultadoFinal = userPesos / dolar;
    parrafoRes.innerHTML = "Tus pesos valen " + resultadoFinal + " Dolares";
  } else if (userMoney == 2) {
    resultadoFinal = userPesos / euro;
    parrafoRes.innerHTML = "Tus pesos valen " + resultadoFinal + " Euros";
  } else if (userMoney == 3) {
    resultadoFinal = userPesos / libra;
    parrafoRes.innerHTML = "Tus pesos valen " + resultadoFinal + " Libras";
  } else {
    parrafoRes.innerHTML = "Tus pesos valen " + resultadoFinal + " Libras";
    alert("No ingresaste una opcion valida");
  }
});

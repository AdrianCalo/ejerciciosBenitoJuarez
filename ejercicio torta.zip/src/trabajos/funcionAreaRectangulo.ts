var A: number = 5;
var B: number = 10;
var Area: number = 0;

Area = B * A;
console.log(Area);

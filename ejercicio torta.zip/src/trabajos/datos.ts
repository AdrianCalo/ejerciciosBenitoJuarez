let btnEnv = document.getElementById("btnEnviar");
let dato1 = document.getElementById("dato1");
let dato2 = document.getElementById("dato2");
let rotulo1 = document.getElementById("rotulo1");
let rotulo2 = document.getElementById("rotulo2");
//rotulo.innerHTML = "indique su domicilio: ";

//function apretaBoton(){
//alert("le diste al boton gato!!")
//}

btnEnv.addEventListener("click", function () {
    // if (dato.value) = null do
   //alert("le diste al boton gato!!)")
   //else
    let datoNumerico1 : number = Number(dato1.value)
    let datoNumerico2 : number = Number(dato2.value)
   let resultado : number = datoNumerico1 + datoNumerico2
  
    console.log( "el resultado de la suma es", resultado);
  });

//usando funcion flecha o arrow =>  es una funcion sin nombre qeu realiza una cierta accion en el momento
// sirve como para este caso, en el que no la voy a volver a usar y realiza la accion justo en el momento
//donde se cometio una accion. en este caso un click.
//tbm se puede crear una funcion en un momento anterior e invocarla en ese momento como el caso de apretaBoton

que pasaria si quiero que me tire un alerta cuando no hay nada y console log cuando haya algo


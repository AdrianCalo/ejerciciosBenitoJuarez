var instruccionTorta = [
  "1. preprar ingredientes",
  "2. mezclar huevo azucar e incorporar harina",
  "3. encender el horno",
  "4. mezclar los ingredientes hasta formar masa",
  "5. enmantecar el horno a utilizar",
  "6. verter el contenido en un molde para horno",
  "7. esperar que el horno se encuentre a una temperatura adecuada",
  "8. meter el molde dentro del horno",
  "9.esperar aproximadamente 45 min",
  "10. sacar el molde del horno, esperar a que se enfrie y desmoldar"
];
for (let i = 0; i < instruccionTorta.length; i++) {
  let instruccion = instruccionTorta[i];
  console.log(instruccion);
}

var numero1, numero2, resultm : number; 
Scanner reader = new Scanner(System.in);
System.out.println("Introduce el primer número:");      
numero1 = reader.nextInt();
System.out.println("Introduce el segundo numero:");      
nuemro2 = reader.nextInt();


resultm = (numero1 + numero2);
console.log(resultm)
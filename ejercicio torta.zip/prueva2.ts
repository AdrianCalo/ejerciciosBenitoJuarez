var num: number;

num = 0;
for (let i = 0; i <= 100; i++) {
  num = num + 2;
  console.log(num);
}

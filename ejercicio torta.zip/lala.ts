//let llegadaColectivo;

//console.log("Esperando el colectivo");
//llegadaColectivo = prompt("Llego el colectivo? (Y/N): ").toUpperCase();
//if (llegadaColectivo != n | | !=y){
//  while (llegadaColectivo=="N") {
//  console.log("Esperando el colectivo");
//  llegadaColectivo =prompt("Llego el colectivo? (Y/N): ").toUpperCase();
//}
//console.log("Llego el colectivo");
//}

//let ruedas = ["R1", "R2", "R3", "R4"];
//for(let i = ruedas.length - 1; i >= 0; i--) {
 // console.log("Infla" + ruedas[i]);
   //   }


let nota: number = 0;
let total: number = 0;
let promedio: number = 0;
//let contador : number=0;
//while (contador <= 10){
for (let contador = 0; contador < 10; contador++) {
  //nota = Number(prompt("ingrese la nota")); // ${(contador)} de 10)
  total = +nota;
  //contador++
}
promedio = total / 10;
console.log("el promedio 1" + promedio);

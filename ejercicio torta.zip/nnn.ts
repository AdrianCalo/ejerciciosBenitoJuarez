var num1 :number = 2; 
var num2 :number = 5;
var num3 :number = 10;


function compare(num1, num2, num3) {
	if (num3 > num2 && num1 > num3) {
		return num1 + ' is the biggest number';
	} else if (num2 > num1 && num2 > num3) {
		return num2 + ' is the biggest number';
	} else {
		return num3 + ' is the biggest number';
	}
}